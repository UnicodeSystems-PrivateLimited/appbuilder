import { Component, ViewEncapsulation } from '@angular/core';
import { DROPDOWN_DIRECTIVES, TAB_DIRECTIVES, TOOLTIP_DIRECTIVES } from 'ng2-bootstrap/ng2-bootstrap';
import { Dialog, Dropdown } from 'primeng/primeng';
import { PageService, GridDataService } from '../../../../../theme/services';
import { RouteParams } from '@angular/router-deprecated';
import { Dragula, DragulaService } from 'ng2-dragula/ng2-dragula';
import { AppsTab, EmailForm, FormField, FieldType, formFieldTypes } from '../../../../../theme/interfaces';
import { EmailFormsService } from './email-forms-tab.service';
import { MobileViewComponent, FormFields, FieldProperties } from '../../../../../components';
import {FormEntryPipe} from '../../../../../pipes/form-entry-pipe.pipe';

@Component({
    selector: 'tab-function-email-forms-tab',
    pipes: [FormEntryPipe],
    directives: [TOOLTIP_DIRECTIVES, Dropdown, Dialog, DROPDOWN_DIRECTIVES, MobileViewComponent, TAB_DIRECTIVES, Dragula, FormFields, FieldProperties],
    encapsulation: ViewEncapsulation.None,
    template: require('./email-forms-tab.component.html'),
    styles: [require('./email-forms-tab.scss')],
    viewProviders: [DragulaService],
    providers: [PageService, EmailFormsService]
})

export class EmailFormsTab {
    public tabId: number;
    public ready: boolean = false;
    public forms: EmailForm[] = [];
    public deleteFormId: number = null;
    public form: EmailForm = new EmailForm();
    public tabData: AppsTab = new AppsTab();
    public fieldTypes: FieldType[] = [];
    public formDialogHeader: string;
    public fields: FormField[] = [];
    public selectedField: FormField = null;
    public fieldTypeIcons: string[] = [];
    public headers = [];
    public entries = [];
    public data = [];
    public deletedField = [];
    public id: number;
    public headerIds: number[] = [];

    // ------------------- DISPLAY CONTROL ----------------------------
    public formDialogDisplay: boolean = false;
    public showDeleteDialog: boolean = false;
    public showLoader: boolean = false;
    public addFieldTabActive: boolean = false;
    public fieldPropsTabActive: boolean = false;
    public formPropsTabActive: boolean = true;
    public entryDialog: boolean = false;

    // ----------------------------------------------------------------

    private FIELD_SIZE_SMALL: number = 1;
    private FIELD_SIZE_MEDIUM: number = 2;
    private FIELD_SIZE_LARGE: number = 3;

    private TIME_FORMAT_12_HOURS: number = 1;
    private TIME_FORMAT_24_HOURS: number = 2;

    private PHONE_FORMAT_NORMAL: number = 1;
    private PHONE_FORMAT_INTERNATIONAL: number = 2;

    private FORMS_BAG: string = "forms-bag";
    private FORM_FIELDS_BAG: string = "form-fields-bag";

    constructor(
        private pageService: PageService,
        private params: RouteParams,
        private service: EmailFormsService,
        private dragulaService: DragulaService,
        private dataService: GridDataService
    ) {
        this.tabId = parseInt(params.get('tabId'));
        this.form.tab_id = this.tabId;

        this.fieldTypeIcons[formFieldTypes.SINGLE_LINE_TEXT] = "fa-edit";
        this.fieldTypeIcons[formFieldTypes.PARAGRAPH_TEXT] = "fa-list-alt";
        this.fieldTypeIcons[formFieldTypes.NUMBER] = "fa-sort-numeric-asc";
        this.fieldTypeIcons[formFieldTypes.CHECKBOXES] = "fa-check-square-o";
        this.fieldTypeIcons[formFieldTypes.MULTIPLE_CHOICES] = "fa-wpforms";
        this.fieldTypeIcons[formFieldTypes.DROPDOWN] = "fa-dropbox";
        this.fieldTypeIcons[formFieldTypes.NAME] = "fa-user";
        this.fieldTypeIcons[formFieldTypes.DATE] = "fa-calendar";
        this.fieldTypeIcons[formFieldTypes.TIME] = "fa-clock-o";
        this.fieldTypeIcons[formFieldTypes.PHONE] = "fa-volume-control-phone";
        this.fieldTypeIcons[formFieldTypes.ADDRESS] = "fa-home";
        this.fieldTypeIcons[formFieldTypes.WEBSITE] = "fa-globe";
        this.fieldTypeIcons[formFieldTypes.PRICE] = "fa-usd";
        this.fieldTypeIcons[formFieldTypes.EMAIL] = "fa-envelope-o";
        this.fieldTypeIcons[formFieldTypes.SECTION_BREAK] = "fa-pencil-square-o";
        this.fieldTypeIcons[formFieldTypes.FILE_UPLOAD] = "fa-upload";

        dragulaService.dropModel.subscribe(value => {
            console.log('drop model');
            console.log(value[0]);
            if (value[0] === this.FORMS_BAG) {
                console.log('condition true');
                this.sort();
            }
        });
    }

    public ngOnInit(): void {
        this.getInitData();
    }

    public getInitData(): void {
        this.service.getInitData(this.tabId).subscribe(res => {
            if (res.success) {
                this.tabData = res.data.tabData;
                this.fieldTypes = res.data.fieldTypes;
                this.forms = res.data.formList;
                this.ready = true;
            } else {
                this.pageService.showError(res.message);
            }
        });
    }

    public onAddCustomFormClick(): void {
        this.formDialogDisplay = true;
        this.formDialogHeader = "Add Custom Form";
    }

    public onAddFieldClick(fieldType: FieldType): void {
        let field: FormField = new FormField();
        field.form_id = this.form.id ? this.form.id : null;
        field.field_type_id = fieldType.id;
        let defaultRules = {
            required: false
        };
        field.properties.label = fieldType.name;
        field.properties.guidelines = "";

        switch (fieldType.id) {
            case formFieldTypes.SINGLE_LINE_TEXT:
            case formFieldTypes.NUMBER:
            case formFieldTypes.PARAGRAPH_TEXT:
            case formFieldTypes.WEBSITE:
            case formFieldTypes.EMAIL:
                field.properties.size = this.FIELD_SIZE_MEDIUM;
            case formFieldTypes.NAME:
            case formFieldTypes.DATE:
            case formFieldTypes.PRICE:
            case formFieldTypes.FILE_UPLOAD:
            case formFieldTypes.ADDRESS:
                field.properties.rules = defaultRules;
                break;

            case formFieldTypes.TIME:
                field.properties.rules = defaultRules;
                field.properties.format = this.TIME_FORMAT_24_HOURS;
                break;

            case formFieldTypes.PHONE:
                field.properties.rules = defaultRules;
                field.properties.phone_format = this.PHONE_FORMAT_NORMAL;
                break;

            case formFieldTypes.DROPDOWN:
                field.properties.size = this.FIELD_SIZE_MEDIUM;
            case formFieldTypes.CHECKBOXES:
            case formFieldTypes.MULTIPLE_CHOICES:
                field.properties.rules = defaultRules;
                field.properties.choices = [
                    { name: "First Option", selected: false },
                    { name: "Second Option", selected: false },
                    { name: "Third Option", selected: false }
                ];
                break;

        }

        this.fields.push(field);
    }

    public onFieldDelete(field): void {
        this.selectedField = null;
        this.deletedField.push(field.id);
    }

    public onFieldClick(field: FormField): void {
        this.selectedField = field;
        this.fieldPropsTabActive = false;
        setTimeout(() => {
            this.fieldPropsTabActive = true;
        }, 0);
    }

    public onAddAnotherFieldClick(): void {
        this.addFieldTabActive = false;
        setTimeout(() => {
            this.addFieldTabActive = true;
        }, 0);
    }

    public onTitleAndDescClick(): void {
        this.activateFormPropsTab();
    }

    private activateFormPropsTab(): void {
        this.formPropsTabActive = false;
        setTimeout(() => {
            this.formPropsTabActive = true;
        }, 0);
    }

    public onSaveFormClick(): void {
        this.showLoader = true;
        // Yes, we are literally saving the form of a Form.
        this.service.saveForm(this.form, this.fields, this.deletedField).subscribe(res => {
            this.showLoader = false;
            if (res.success) {
                this.formDialogDisplay = false;
                this.dataService.getByID(this.forms, res.data.insertedId, (form: EmailForm) => {
                    form.title = this.form.title;
                }, () => {
                    let form: EmailForm = new EmailForm();
                    form.id = res.data.insertedId;
                    form.title = this.form.title;
                    this.deletedField = [];
                    this.forms.push(form);
                });
                this.onAfterDialogHide();
                this.pageService.showSuccess(res.message);
            } else {
                this.pageService.showError(res.message);
            };
        });
    }

    public onEditFormClick(id: number): void {
        this.formDialogHeader = "Edit Custom Form";
        PageService.showLoader();
        this.service.getForm(id).subscribe(res => {
            PageService.hideLoader();
            if (res.success) {
                this.formDialogDisplay = true;
                this.form = res.data.form;
                this.fields = res.data.fields;
            } else {
                this.pageService.showError(res.message);
            }
        });
    }

    public onAfterDialogHide(): void {
        this.selectedField = null;
        this.activateFormPropsTab();
        this.form = new EmailForm();
        this.form.tab_id = this.tabId;
        this.fields = [];
        this.deletedField = [];
    }

    public sort(): void {
        let ids: number[] = [];
        for (let form of this.forms) {
            ids.push(form.id);
        }
        this.service.sortForms(ids).subscribe(res => {
            if (res.success) {
                this.pageService.showSuccess(res.message);
            } else {
                this.pageService.showError(res.message);
            }
        });
    }

    public onDeleteFormClick(id: number): void {
        if (!confirm("Are you sure you want to delete this form ?")) {
            return;
        }
        this.showLoader = true;
        this.service.deleteForm([id]).subscribe(res => {
            if (res.success) {
                this.showLoader = false;
                this.pageService.showSuccess(res.message);
                this.dataService.getByID(this.forms, id, (form, index) => {
                    this.forms.splice(index, 1);
                });
            } else {
                this.pageService.showError(res.message);
            }
        });
    }

    public onEntryClick(form_id): void {
        this.entryDialog = true;
        this.id = form_id;
        this.service.listEmailFormEntries(form_id).subscribe(res => {
            PageService.hideLoader();
            if (res.success) {
                this.headers = res.data.header;
                this.entries = res.data.entries;
                this.initHeaderIds();
            } else {
                this.pageService.showError(res.message);
            }
        });
    }

    public onEntryDeleteClick(id): void {
        if (!confirm("Are you sure you want to delete this entry ?")) {
            return;
        }
        this.showLoader = true;
        this.service.deleteEntry([id]).subscribe(res => {
            if (res.success) {
                this.showLoader = false;
                this.pageService.showSuccess(res.message);
                this.entries.forEach((entry, index) => {
                    if (id) {
                        this.entries.splice(index, 1);
                    }
                });
            } else {
                this.pageService.showError(res.message);
            }
        });
    }

    private initHeaderIds(): void {
        this.headerIds = [];
        for (let val of this.headers) {
            this.headerIds.push(val.id);
        }
    }
}